import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import { DataProvider } from './context/DataContext';

function App() {
  return (
    <ThemeProvider>
      <DataProvider>
        <Layout>
          <Dashboard />
        </Layout>
      </DataProvider>
    </ThemeProvider>
  );
}

export default App;