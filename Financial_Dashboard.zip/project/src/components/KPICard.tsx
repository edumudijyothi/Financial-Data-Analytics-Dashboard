import React from 'react';
import { ArrowUpRight, ArrowDownRight, Activity } from 'lucide-react';

interface KPICardProps {
  data: {
    title: string;
    value: string;
    change: number;
    trend: 'up' | 'down';
    chart: number[];
    performance?: number;
  };
  isLoading: boolean;
}

const KPICard: React.FC<KPICardProps> = ({ data, isLoading }) => {
  const { title, value, change, trend, chart, performance } = data;
  const isPositive = trend === 'up';

  if (isLoading) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 animate-pulse transition-all duration-200">
        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-4"></div>
        <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-2/3 mb-4"></div>
        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4 mb-4"></div>
        <div className="h-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
      </div>
    );
  }

  // Render mini sparkline with SVG
  const chartWidth = 100;
  const chartHeight = 30;
  const max = Math.max(...chart);
  const min = Math.min(...chart);
  const range = max - min;
  
  const points = chart.map((value, index) => {
    const x = (index / (chart.length - 1)) * chartWidth;
    const y = chartHeight - ((value - min) / range) * chartHeight;
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 hover:shadow-md transition-all duration-200 group">
      <div className="flex justify-between items-start mb-2">
        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</h3>
        {performance && (
          <div className="flex items-center bg-blue-50 dark:bg-blue-900/20 px-2 py-1 rounded">
            <Activity className="h-3 w-3 text-blue-500 dark:text-blue-400 mr-1" />
            <span className="text-xs font-medium text-blue-600 dark:text-blue-400">{performance}%</span>
          </div>
        )}
      </div>
      
      <p className="mt-2 text-3xl font-semibold text-gray-900 dark:text-white">{value}</p>
      
      <div className="mt-2 flex items-center">
        {isPositive ? (
          <ArrowUpRight className="h-4 w-4 text-green-500" />
        ) : (
          <ArrowDownRight className="h-4 w-4 text-red-500" />
        )}
        
        <span className={`ml-1 text-sm font-medium ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
          {change}%
        </span>
        
        <span className="ml-1 text-sm text-gray-500 dark:text-gray-400">
          {isPositive ? 'increase' : 'decrease'}
        </span>
      </div>
      
      <div className="mt-4">
        <svg width={chartWidth} height={chartHeight} className="overflow-visible">
          <polyline
            points={points}
            fill="none"
            stroke={isPositive ? "#10B981" : "#EF4444"}
            strokeWidth="2"
            className="opacity-75 group-hover:opacity-100 transition-opacity"
          />
        </svg>
      </div>
    </div>
  );
};

export default KPICard;