import React, { useState } from 'react';
import { 
  Search, 
  Bell, 
  User, 
  Moon, 
  Sun, 
  Menu, 
  X,
  Download,
  Settings
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

const Navbar: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 transition-colors duration-200">
      <div className="max-w-full mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-xl font-bold text-blue-900 dark:text-blue-400">FinDash</h1>
            </div>
            <div className="hidden md:block ml-10">
              <div className="flex items-center space-x-4">
                <a href="#" className="text-blue-900 dark:text-white px-3 py-2 rounded-md text-sm font-medium">Dashboard</a>
                <a href="#" className="text-gray-500 hover:text-blue-900 dark:text-gray-300 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium">Reports</a>
                <a href="#" className="text-gray-500 hover:text-blue-900 dark:text-gray-300 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium">Analytics</a>
                <a href="#" className="text-gray-500 hover:text-blue-900 dark:text-gray-300 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium">Forecasting</a>
              </div>
            </div>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-4 flex items-center md:ml-6">
              <div className="relative mx-2">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="text"
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md leading-5 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition-colors duration-200"
                  placeholder="Search..."
                />
              </div>
              
              <button className="p-1 rounded-full text-gray-500 dark:text-gray-400 hover:text-blue-900 dark:hover:text-white focus:outline-none">
                <span className="sr-only">Download Report</span>
                <Download className="h-6 w-6" />
              </button>
              
              <button className="ml-3 p-1 rounded-full text-gray-500 dark:text-gray-400 hover:text-blue-900 dark:hover:text-white focus:outline-none">
                <span className="sr-only">View notifications</span>
                <Bell className="h-6 w-6" />
              </button>
              
              <button 
                onClick={toggleTheme}
                className="ml-3 p-1 rounded-full text-gray-500 dark:text-gray-400 hover:text-blue-900 dark:hover:text-white focus:outline-none"
              >
                <span className="sr-only">Toggle theme</span>
                {theme === 'dark' ? <Sun className="h-6 w-6" /> : <Moon className="h-6 w-6" />}
              </button>
              
              <button className="ml-3 p-1 rounded-full text-gray-500 dark:text-gray-400 hover:text-blue-900 dark:hover:text-white focus:outline-none">
                <span className="sr-only">Settings</span>
                <Settings className="h-6 w-6" />
              </button>
              
              <div className="ml-3 relative">
                <button className="max-w-xs bg-blue-100 dark:bg-gray-700 rounded-full flex items-center text-sm focus:outline-none">
                  <span className="sr-only">Open user menu</span>
                  <User className="h-8 w-8 rounded-full p-1 text-blue-900 dark:text-blue-400" />
                </button>
              </div>
            </div>
          </div>
          
          <div className="flex md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-500 dark:text-gray-400 hover:text-blue-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none"
            >
              <span className="sr-only">Open main menu</span>
              {mobileMenuOpen ? (
                <X className="block h-6 w-6" />
              ) : (
                <Menu className="block h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-gray-800 transition-colors duration-200">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-blue-900 dark:text-white bg-gray-100 dark:bg-gray-700">Dashboard</a>
            <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-gray-500 hover:text-blue-900 dark:text-gray-300 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700">Reports</a>
            <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-gray-500 hover:text-blue-900 dark:text-gray-300 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700">Analytics</a>
            <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-gray-500 hover:text-blue-900 dark:text-gray-300 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700">Forecasting</a>
          </div>
          <div className="pt-4 pb-3 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center px-5">
              <div className="flex-shrink-0">
                <User className="h-8 w-8 rounded-full p-1 bg-blue-100 dark:bg-gray-700 text-blue-900 dark:text-blue-400" />
              </div>
              <div className="ml-3">
                <div className="text-base font-medium leading-none text-gray-800 dark:text-white">John Smith</div>
                <div className="text-sm font-medium leading-none text-gray-500 dark:text-gray-400">john@example.com</div>
              </div>
              <button 
                onClick={toggleTheme}
                className="ml-auto p-1 rounded-full text-gray-500 dark:text-gray-400 hover:text-blue-900 dark:hover:text-white focus:outline-none"
              >
                {theme === 'dark' ? <Sun className="h-6 w-6" /> : <Moon className="h-6 w-6" />}
              </button>
              <button className="ml-auto flex-shrink-0 p-1 rounded-full text-gray-500 dark:text-gray-400 hover:text-blue-900 dark:hover:text-white focus:outline-none">
                <Bell className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;