import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  LineChart, 
  BarChart3, 
  PieChart,
  Wallet,
  FileText,
  TrendingUp,
  Settings,
  PanelLeft,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import { useFinancialData } from '../context/DataContext';

const Sidebar: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const { activeSectors, toggleSector, sectorsData } = useFinancialData();

  const toggleCollapse = () => {
    setCollapsed(!collapsed);
  };

  return (
    <div className={`${collapsed ? 'w-16' : 'w-64'} bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col transition-all duration-300 ease-in-out`}>
      <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
        <div className="flex items-center flex-shrink-0 px-4 justify-between">
          {!collapsed && (
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Analytics</h2>
          )}
          <button
            onClick={toggleCollapse}
            className="p-1 rounded-full text-gray-400 hover:text-blue-900 dark:hover:text-white focus:outline-none"
          >
            {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
          </button>
        </div>
        <nav className="mt-5 flex-1 px-2 space-y-1">
          <a
            href="#"
            className="group flex items-center px-2 py-2 text-sm font-medium rounded-md bg-blue-50 dark:bg-blue-900/20 text-blue-900 dark:text-blue-200"
          >
            <LayoutDashboard className={`${collapsed ? 'mx-auto' : 'mr-3'} h-5 w-5`} />
            {!collapsed && <span>Dashboard</span>}
          </a>
          <a
            href="#"
            className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-blue-900 dark:hover:text-white"
          >
            <LineChart className={`${collapsed ? 'mx-auto' : 'mr-3'} h-5 w-5`} />
            {!collapsed && <span>Performance</span>}
          </a>
          <a
            href="#"
            className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-blue-900 dark:hover:text-white"
          >
            <BarChart3 className={`${collapsed ? 'mx-auto' : 'mr-3'} h-5 w-5`} />
            {!collapsed && <span>Revenue</span>}
          </a>
          <a
            href="#"
            className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-blue-900 dark:hover:text-white"
          >
            <PieChart className={`${collapsed ? 'mx-auto' : 'mr-3'} h-5 w-5`} />
            {!collapsed && <span>Sectors</span>}
          </a>
          <a
            href="#"
            className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-blue-900 dark:hover:text-white"
          >
            <Wallet className={`${collapsed ? 'mx-auto' : 'mr-3'} h-5 w-5`} />
            {!collapsed && <span>Expenses</span>}
          </a>
          <a
            href="#"
            className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-blue-900 dark:hover:text-white"
          >
            <FileText className={`${collapsed ? 'mx-auto' : 'mr-3'} h-5 w-5`} />
            {!collapsed && <span>Reports</span>}
          </a>
          <a
            href="#"
            className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-blue-900 dark:hover:text-white"
          >
            <TrendingUp className={`${collapsed ? 'mx-auto' : 'mr-3'} h-5 w-5`} />
            {!collapsed && <span>Forecasting</span>}
          </a>
        </nav>
      </div>
      
      {!collapsed && (
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">Sectors</h3>
          <div className="space-y-2">
            {sectorsData.map((sector) => (
              <div key={sector.id} className="flex items-center">
                <input
                  id={`sector-${sector.id}`}
                  name={`sector-${sector.id}`}
                  type="checkbox"
                  checked={activeSectors.includes(sector.id)}
                  onChange={() => toggleSector(sector.id)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label
                  htmlFor={`sector-${sector.id}`}
                  className="ml-2 block text-sm text-gray-700 dark:text-gray-300"
                >
                  {sector.name}
                </label>
              </div>
            ))}
          </div>
        </div>
      )}
      
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <a
          href="#"
          className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-blue-900 dark:hover:text-white"
        >
          <Settings className={`${collapsed ? 'mx-auto' : 'mr-3'} h-5 w-5`} />
          {!collapsed && <span>Settings</span>}
        </a>
      </div>
    </div>
  );
};

export default Sidebar;