import React, { useState } from 'react';
import { useFinancialData } from '../../context/DataContext';

interface ExpenseBreakdownProps {
  isLoading: boolean;
}

// Mock expense breakdown data
const expenseCategories = [
  { id: 'operations', name: 'Operations', value: 35, color: '#0F52BA' },
  { id: 'marketing', name: 'Marketing', value: 25, color: '#00A86B' },
  { id: 'rd', name: 'R&D', value: 20, color: '#FFA500' },
  { id: 'admin', name: 'Admin', value: 15, color: '#9370DB' },
  { id: 'other', name: 'Other', value: 5, color: '#6B7280' }
];

const ExpenseBreakdown: React.FC<ExpenseBreakdownProps> = ({ isLoading }) => {
  const [activeSlice, setActiveSlice] = useState<string | null>(null);
  
  // Constants for pie chart
  const size = 200;
  const center = size / 2;
  const radius = center - 10;
  
  // Calculate total
  const total = expenseCategories.reduce((sum, category) => sum + category.value, 0);
  
  // Create pie slices
  let currentAngle = 0;
  const slices = expenseCategories.map(category => {
    const angle = (category.value / total) * 360;
    const startAngle = currentAngle;
    const endAngle = currentAngle + angle;
    currentAngle = endAngle;
    
    // Convert angles to radians
    const startRad = (startAngle - 90) * (Math.PI / 180);
    const endRad = (endAngle - 90) * (Math.PI / 180);
    
    // Calculate path
    const x1 = center + radius * Math.cos(startRad);
    const y1 = center + radius * Math.sin(startRad);
    const x2 = center + radius * Math.cos(endRad);
    const y2 = center + radius * Math.sin(endRad);
    
    // Determine large arc flag
    const largeArcFlag = angle > 180 ? 1 : 0;
    
    // Create SVG path
    const path = `M ${center} ${center} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2} Z`;
    
    // Calculate label position
    const labelRad = (startAngle + angle / 2 - 90) * (Math.PI / 180);
    const labelRadius = radius * 0.7;
    const labelX = center + labelRadius * Math.cos(labelRad);
    const labelY = center + labelRadius * Math.sin(labelRad);
    
    // Calculate exploded position
    const explodeRad = (startAngle + angle / 2 - 90) * (Math.PI / 180);
    const explodeOffset = activeSlice === category.id ? 10 : 0;
    const explodeX = explodeOffset * Math.cos(explodeRad);
    const explodeY = explodeOffset * Math.sin(explodeRad);
    
    return {
      ...category,
      path,
      angle,
      labelX,
      labelY,
      explodeX,
      explodeY
    };
  });
  
  if (isLoading) {
    return (
      <div className="animate-pulse flex flex-col items-center justify-center h-64">
        <div className="h-40 w-40 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
        <div className="mt-4 h-4 bg-gray-200 dark:bg-gray-700 rounded w-full"></div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0">
      <div className="w-full md:w-1/2 flex justify-center">
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          {slices.map(slice => (
            <g
              key={slice.id}
              transform={`translate(${slice.explodeX}, ${slice.explodeY})`}
              onMouseEnter={() => setActiveSlice(slice.id)}
              onMouseLeave={() => setActiveSlice(null)}
              className="cursor-pointer transition-transform duration-300"
            >
              <path
                d={slice.path}
                fill={slice.color}
                stroke="#fff"
                strokeWidth="2"
                className={`transition-opacity duration-300 ${
                  activeSlice && activeSlice !== slice.id ? 'opacity-60' : 'opacity-100'
                }`}
              />
              {slice.angle > 20 && (
                <text
                  x={slice.labelX}
                  y={slice.labelY}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill="#fff"
                  fontSize="12"
                  fontWeight="bold"
                  className="pointer-events-none"
                >
                  {slice.value}%
                </text>
              )}
            </g>
          ))}
        </svg>
      </div>
      
      <div className="w-full md:w-1/2">
        <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Expense Categories</h3>
        <ul className="space-y-2">
          {expenseCategories.map(category => (
            <li
              key={category.id}
              className={`flex items-center justify-between p-2 rounded transition-colors duration-200 ${
                activeSlice === category.id
                  ? 'bg-gray-100 dark:bg-gray-700'
                  : 'hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
              onMouseEnter={() => setActiveSlice(category.id)}
              onMouseLeave={() => setActiveSlice(null)}
            >
              <div className="flex items-center">
                <div
                  className="w-3 h-3 rounded-sm mr-2"
                  style={{ backgroundColor: category.color }}
                ></div>
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {category.name}
                </span>
              </div>
              <span className="text-sm font-medium text-gray-900 dark:text-white">
                {category.value}%
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ExpenseBreakdown;