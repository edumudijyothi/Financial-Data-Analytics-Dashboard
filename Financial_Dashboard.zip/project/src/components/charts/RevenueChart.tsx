import React from 'react';
import { useFinancialData } from '../../context/DataContext';

interface RevenueChartProps {
  isLoading: boolean;
}

const RevenueChart: React.FC<RevenueChartProps> = ({ isLoading }) => {
  const { financialData } = useFinancialData();
  
  // SVG chart dimensions
  const svgWidth = 800;
  const svgHeight = 300;
  const margin = { top: 20, right: 20, bottom: 30, left: 50 };
  const width = svgWidth - margin.left - margin.right;
  const height = svgHeight - margin.top - margin.bottom;
  
  // Find max values for scaling
  const maxRevenue = Math.max(...financialData.map(d => d.revenue));
  const maxExpenses = Math.max(...financialData.map(d => d.expenses));
  const maxValue = Math.max(maxRevenue, maxExpenses) * 1.1; // Add 10% padding
  
  // Create line path for revenue
  const revenueLine = financialData.map((d, i) => {
    const x = (i / (financialData.length - 1)) * width;
    const y = height - (d.revenue / maxValue) * height;
    return `${i === 0 ? 'M' : 'L'}${x},${y}`;
  }).join(' ');
  
  // Create line path for expenses
  const expensesLine = financialData.map((d, i) => {
    const x = (i / (financialData.length - 1)) * width;
    const y = height - (d.expenses / maxValue) * height;
    return `${i === 0 ? 'M' : 'L'}${x},${y}`;
  }).join(' ');
  
  // Create area path for profit (the area between revenue and expenses)
  const profitArea = financialData.map((d, i) => {
    const x = (i / (financialData.length - 1)) * width;
    const y1 = height - (d.revenue / maxValue) * height;
    const y2 = height - (d.expenses / maxValue) * height;
    return `${i === 0 ? 'M' : 'L'}${x},${y1}`;
  }).join(' ') + ' ' + financialData.map((d, i) => {
    const x = width - (i / (financialData.length - 1)) * width;
    const y = height - (d.expenses / maxValue) * height;
    return `L${x},${y}`;
  }).reverse().join(' ') + ' Z';
  
  // X-axis labels (months)
  const xLabels = financialData.map((d, i) => ({
    x: (i / (financialData.length - 1)) * width,
    label: d.month
  }));
  
  // Y-axis labels (money values)
  const yLabels = Array.from({ length: 5 }, (_, i) => ({
    y: height - (i / 4) * height,
    label: `$${Math.round(maxValue * (i / 4) / 1000)}k`
  }));
  
  if (isLoading) {
    return (
      <div className="animate-pulse flex flex-col">
        <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
      </div>
    );
  }
  
  return (
    <div className="relative h-64">
      <svg width="100%" height="100%" viewBox={`0 0 ${svgWidth} ${svgHeight}`} preserveAspectRatio="none">
        <g transform={`translate(${margin.left}, ${margin.top})`}>
          {/* Grid lines */}
          {yLabels.map((label, i) => (
            <line
              key={`grid-${i}`}
              x1="0"
              y1={label.y}
              x2={width}
              y2={label.y}
              stroke="#e5e7eb"
              strokeDasharray="4 4"
              className="dark:stroke-gray-700"
            />
          ))}
          
          {/* Profit area */}
          <path
            d={profitArea}
            fill="url(#profit-gradient)"
            opacity="0.2"
            className="transition-opacity duration-300"
          />
          
          {/* Revenue line */}
          <path
            d={revenueLine}
            fill="none"
            stroke="#0F52BA"
            strokeWidth="3"
            className="transition-colors duration-300 dark:stroke-blue-400"
          />
          
          {/* Expenses line */}
          <path
            d={expensesLine}
            fill="none"
            stroke="#ef4444"
            strokeWidth="3"
            className="transition-colors duration-300 dark:stroke-red-400"
          />
          
          {/* X-axis */}
          <line
            x1="0"
            y1={height}
            x2={width}
            y2={height}
            stroke="#9ca3af"
            className="dark:stroke-gray-600"
          />
          
          {/* X-axis labels */}
          {xLabels.map((label, i) => (
            <React.Fragment key={`x-label-${i}`}>
              <line
                x1={label.x}
                y1={height}
                x2={label.x}
                y2={height + 6}
                stroke="#9ca3af"
                className="dark:stroke-gray-600"
              />
              <text
                x={label.x}
                y={height + 20}
                textAnchor="middle"
                fontSize="12"
                fill="#6b7280"
                className="dark:fill-gray-400"
              >
                {label.label}
              </text>
            </React.Fragment>
          ))}
          
          {/* Y-axis */}
          <line
            x1="0"
            y1="0"
            x2="0"
            y2={height}
            stroke="#9ca3af"
            className="dark:stroke-gray-600"
          />
          
          {/* Y-axis labels */}
          {yLabels.map((label, i) => (
            <text
              key={`y-label-${i}`}
              x="-10"
              y={label.y}
              textAnchor="end"
              dominantBaseline="middle"
              fontSize="12"
              fill="#6b7280"
              className="dark:fill-gray-400"
            >
              {label.label}
            </text>
          ))}
          
          {/* Data point circles for revenue */}
          {financialData.map((d, i) => {
            const x = (i / (financialData.length - 1)) * width;
            const y = height - (d.revenue / maxValue) * height;
            return (
              <circle
                key={`revenue-point-${i}`}
                cx={x}
                cy={y}
                r="4"
                fill="#0F52BA"
                className="dark:fill-blue-400"
              />
            );
          })}
          
          {/* Data point circles for expenses */}
          {financialData.map((d, i) => {
            const x = (i / (financialData.length - 1)) * width;
            const y = height - (d.expenses / maxValue) * height;
            return (
              <circle
                key={`expenses-point-${i}`}
                cx={x}
                cy={y}
                r="4"
                fill="#ef4444"
                className="dark:fill-red-400"
              />
            );
          })}
        </g>
        
        {/* Gradient for profit area */}
        <defs>
          <linearGradient id="profit-gradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#0F52BA" stopOpacity="0.8" className="dark:stop-color-blue-400" />
            <stop offset="100%" stopColor="#0F52BA" stopOpacity="0.1" className="dark:stop-color-blue-400" />
          </linearGradient>
        </defs>
      </svg>
      
      {/* Legend */}
      <div className="absolute bottom-0 right-0 flex items-center space-x-4 mb-4 mr-4">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-blue-700 rounded-full mr-1 dark:bg-blue-400"></div>
          <span className="text-xs text-gray-600 dark:text-gray-300">Revenue</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-red-500 rounded-full mr-1 dark:bg-red-400"></div>
          <span className="text-xs text-gray-600 dark:text-gray-300">Expenses</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-blue-700 opacity-20 rounded-sm mr-1 dark:bg-blue-400"></div>
          <span className="text-xs text-gray-600 dark:text-gray-300">Profit</span>
        </div>
      </div>
    </div>
  );
};

export default RevenueChart;