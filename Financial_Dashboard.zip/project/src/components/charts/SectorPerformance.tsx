import React, { useState } from 'react';
import { useFinancialData } from '../../context/DataContext';

interface SectorPerformanceProps {
  isLoading: boolean;
}

const SectorPerformance: React.FC<SectorPerformanceProps> = ({ isLoading }) => {
  const { sectorsData, activeSectors } = useFinancialData();
  const [activeMetric, setActiveMetric] = useState<'revenue' | 'growth' | 'margin'>('revenue');
  
  const filteredSectors = sectorsData.filter(sector => activeSectors.includes(sector.id));
  
  // Get metric values based on active metric
  const getMetricValue = (sector: any) => {
    switch (activeMetric) {
      case 'revenue':
        return sector.revenue;
      case 'growth':
        return sector.growth;
      case 'margin':
        return sector.margin;
      default:
        return 0;
    }
  };
  
  // Get formatted metric label
  const getMetricLabel = (value: number) => {
    switch (activeMetric) {
      case 'revenue':
        return `$${(value / 1000).toFixed(0)}k`;
      case 'growth':
      case 'margin':
        return `${value.toFixed(1)}%`;
      default:
        return value.toString();
    }
  };
  
  // Calculate max value for scaling
  const maxValue = Math.max(...filteredSectors.map(getMetricValue)) * 1.1;
  
  // Chart dimensions
  const barHeight = 40;
  const barGap = 20;
  const chartHeight = filteredSectors.length * (barHeight + barGap);
  const chartWidth = 400;
  
  if (isLoading) {
    return (
      <div className="animate-pulse flex flex-col space-y-4">
        <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
        <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
      </div>
    );
  }
  
  return (
    <div className="h-64">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex space-x-2">
          <button
            className={`px-3 py-1 text-xs font-medium rounded-full ${
              activeMetric === 'revenue'
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
            } transition-colors duration-200`}
            onClick={() => setActiveMetric('revenue')}
          >
            Revenue
          </button>
          <button
            className={`px-3 py-1 text-xs font-medium rounded-full ${
              activeMetric === 'growth'
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
            } transition-colors duration-200`}
            onClick={() => setActiveMetric('growth')}
          >
            Growth
          </button>
          <button
            className={`px-3 py-1 text-xs font-medium rounded-full ${
              activeMetric === 'margin'
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
            } transition-colors duration-200`}
            onClick={() => setActiveMetric('margin')}
          >
            Margin
          </button>
        </div>
      </div>
      
      <div className="overflow-hidden h-full">
        <svg width="100%" height={chartHeight} className="overflow-visible">
          {filteredSectors.map((sector, index) => {
            const value = getMetricValue(sector);
            const barWidth = (value / maxValue) * chartWidth;
            const y = index * (barHeight + barGap);
            
            return (
              <g key={sector.id} transform={`translate(0, ${y})`}>
                {/* Sector name label */}
                <text
                  x="0"
                  y={barHeight / 2}
                  dominantBaseline="middle"
                  className="text-sm fill-gray-700 dark:fill-gray-300"
                >
                  {sector.name}
                </text>
                
                {/* Background bar */}
                <rect
                  x="120"
                  y="0"
                  width={chartWidth}
                  height={barHeight}
                  rx="4"
                  className="fill-gray-100 dark:fill-gray-700"
                />
                
                {/* Value bar with animation */}
                <rect
                  x="120"
                  y="0"
                  width={barWidth}
                  height={barHeight}
                  rx="4"
                  fill={sector.color}
                  className="transition-all duration-500 opacity-80 hover:opacity-100"
                />
                
                {/* Value label */}
                <text
                  x={120 + barWidth + 10}
                  y={barHeight / 2}
                  dominantBaseline="middle"
                  className="text-sm font-medium fill-gray-700 dark:fill-gray-300"
                >
                  {getMetricLabel(value)}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
};

export default SectorPerformance;