import React, { useState } from 'react';
import { useFinancialData } from '../../context/DataContext';

interface TrendPredictionProps {
  isLoading: boolean;
}

const TrendPrediction: React.FC<TrendPredictionProps> = ({ isLoading }) => {
  const { trendData } = useFinancialData();
  const [activeMetric, setActiveMetric] = useState<'revenue' | 'expenses' | 'profit'>('profit');
  
  // Choose the appropriate data based on active metric
  const data = trendData[activeMetric];
  
  // SVG chart dimensions
  const svgWidth = 800;
  const svgHeight = 300;
  const margin = { top: 20, right: 20, bottom: 30, left: 50 };
  const width = svgWidth - margin.left - margin.right;
  const height = svgHeight - margin.top - margin.bottom;
  
  // Find max value for scaling
  const maxValue = Math.max(...[...data.actual, ...data.predicted]) * 1.1;
  
  // Create line path for actual data
  const actualLine = data.actual.map((d, i) => {
    const x = (i / (data.predicted.length - 1)) * width;
    const y = height - (d / maxValue) * height;
    return `${i === 0 ? 'M' : 'L'}${x},${y}`;
  }).join(' ');
  
  // Create line path for predicted data
  const predictedLine = data.predicted.map((d, i) => {
    const x = (i / (data.predicted.length - 1)) * width;
    const y = height - (d / maxValue) * height;
    return `${i === 0 ? 'M' : 'L'}${x},${y}`;
  }).join(' ');
  
  // Find the point where actual data ends and prediction begins
  const predictionStartIndex = data.actual.length - 1;
  const predictionStartX = (predictionStartIndex / (data.predicted.length - 1)) * width;
  
  // Get colors based on active metric
  const getMetricColor = () => {
    switch (activeMetric) {
      case 'revenue':
        return '#0F52BA';
      case 'expenses':
        return '#ef4444';
      case 'profit':
        return '#10B981';
      default:
        return '#0F52BA';
    }
  };
  
  // X-axis labels
  const xLabels = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    'Jan', 'Feb', 'Mar', 'Apr'
  ].slice(0, data.predicted.length);
  
  // Line for showing where prediction starts
  const predictionLine = `M${predictionStartX},0 L${predictionStartX},${height}`;
  
  if (isLoading) {
    return (
      <div className="animate-pulse flex flex-col">
        <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-4"></div>
        <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
      </div>
    );
  }
  
  return (
    <div className="h-64">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex space-x-2">
          <button
            className={`px-3 py-1 text-xs font-medium rounded-full ${
              activeMetric === 'profit'
                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
            } transition-colors duration-200`}
            onClick={() => setActiveMetric('profit')}
          >
            Profit
          </button>
          <button
            className={`px-3 py-1 text-xs font-medium rounded-full ${
              activeMetric === 'revenue'
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
            } transition-colors duration-200`}
            onClick={() => setActiveMetric('revenue')}
          >
            Revenue
          </button>
          <button
            className={`px-3 py-1 text-xs font-medium rounded-full ${
              activeMetric === 'expenses'
                ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
            } transition-colors duration-200`}
            onClick={() => setActiveMetric('expenses')}
          >
            Expenses
          </button>
        </div>
      </div>
      
      <div className="relative h-full">
        <svg width="100%" height="100%" viewBox={`0 0 ${svgWidth} ${svgHeight}`} preserveAspectRatio="none">
          <g transform={`translate(${margin.left}, ${margin.top})`}>
            {/* Grid lines */}
            {Array.from({ length: 5 }, (_, i) => (
              <line
                key={`grid-${i}`}
                x1="0"
                y1={height - (i / 4) * height}
                x2={width}
                y2={height - (i / 4) * height}
                stroke="#e5e7eb"
                strokeDasharray="4 4"
                className="dark:stroke-gray-700"
              />
            ))}
            
            {/* Prediction start line */}
            <path
              d={predictionLine}
              stroke="#9ca3af"
              strokeDasharray="4 4"
              className="dark:stroke-gray-600"
            />
            
            {/* Actual line */}
            <path
              d={actualLine}
              fill="none"
              stroke={getMetricColor()}
              strokeWidth="3"
              className="transition-colors duration-300"
            />
            
            {/* Predicted line */}
            <path
              d={predictedLine}
              fill="none"
              stroke={getMetricColor()}
              strokeDasharray="5 5"
              strokeWidth="3"
              className="transition-colors duration-300"
              opacity="0.7"
            />
            
            {/* X-axis */}
            <line
              x1="0"
              y1={height}
              x2={width}
              y2={height}
              stroke="#9ca3af"
              className="dark:stroke-gray-600"
            />
            
            {/* X-axis labels */}
            {xLabels.map((label, i) => {
              const x = (i / (data.predicted.length - 1)) * width;
              return (
                <text
                  key={`x-label-${i}`}
                  x={x}
                  y={height + 20}
                  textAnchor="middle"
                  fontSize="10"
                  fill="#6b7280"
                  className="dark:fill-gray-400"
                >
                  {label}
                </text>
              );
            })}
            
            {/* Prediction label */}
            <text
              x={predictionStartX + 5}
              y="15"
              fontSize="10"
              fill="#6b7280"
              className="dark:fill-gray-400"
            >
              Prediction →
            </text>
            
            {/* Data points for actual */}
            {data.actual.map((d, i) => {
              const x = (i / (data.predicted.length - 1)) * width;
              const y = height - (d / maxValue) * height;
              return (
                <circle
                  key={`point-${i}`}
                  cx={x}
                  cy={y}
                  r="4"
                  fill={getMetricColor()}
                />
              );
            })}
          </g>
        </svg>
        
        {/* Legend */}
        <div className="absolute bottom-0 right-0 flex items-center space-x-4 mb-4 mr-4">
          <div className="flex items-center">
            <div 
              className="w-3 h-3 rounded-full mr-1"
              style={{ backgroundColor: getMetricColor() }}
            ></div>
            <span className="text-xs text-gray-600 dark:text-gray-300">Actual</span>
          </div>
          <div className="flex items-center">
            <div 
              className="w-3 h-0 border border-dashed border-2 mr-1"
              style={{ borderColor: getMetricColor() }}
            ></div>
            <span className="text-xs text-gray-600 dark:text-gray-300">Predicted</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrendPrediction;