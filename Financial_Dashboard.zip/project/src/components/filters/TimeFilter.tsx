import React from 'react';
import { useFinancialData } from '../../context/DataContext';

const TimeFilter: React.FC = () => {
  const { timeRange, setTimeRange } = useFinancialData();

  return (
    <div className="mt-4 lg:mt-0 bg-white dark:bg-gray-800 rounded-lg shadow p-2 inline-flex transition-colors duration-200">
      <button
        onClick={() => setTimeRange('month')}
        className={`px-4 py-2 text-sm font-medium rounded ${
          timeRange === 'month'
            ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-900 dark:text-blue-200'
            : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
        } transition-colors duration-200`}
      >
        Monthly
      </button>
      <button
        onClick={() => setTimeRange('quarter')}
        className={`px-4 py-2 text-sm font-medium rounded ${
          timeRange === 'quarter'
            ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-900 dark:text-blue-200'
            : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
        } transition-colors duration-200`}
      >
        Quarterly
      </button>
      <button
        onClick={() => setTimeRange('year')}
        className={`px-4 py-2 text-sm font-medium rounded ${
          timeRange === 'year'
            ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-900 dark:text-blue-200'
            : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
        } transition-colors duration-200`}
      >
        Yearly
      </button>
    </div>
  );
};

export default TimeFilter;