import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  monthlyData,
  quarterlyData,
  yearlyData,
  sectorsData, 
  kpiData, 
  trendData 
} from '../data/mockData';

type TimeRange = 'month' | 'quarter' | 'year';

export interface FinancialContextType {
  financialData: any[];
  sectorsData: any[];
  kpiData: any[];
  trendData: any;
  timeRange: TimeRange;
  setTimeRange: (range: TimeRange) => void;
  activeSectors: string[];
  toggleSector: (sector: string) => void;
  isLoading: boolean;
}

const DataContext = createContext<FinancialContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [timeRange, setTimeRange] = useState<TimeRange>('month');
  const [activeSectors, setActiveSectors] = useState<string[]>(sectorsData.map(s => s.id));
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Get the appropriate financial data based on time range
  const getFinancialData = () => {
    switch (timeRange) {
      case 'month':
        return monthlyData;
      case 'quarter':
        return quarterlyData;
      case 'year':
        return yearlyData;
      default:
        return monthlyData;
    }
  };

  // Get the appropriate KPI data based on time range
  const getKPIData = () => {
    switch (timeRange) {
      case 'month':
        return kpiData.monthly;
      case 'quarter':
        return kpiData.quarterly;
      case 'year':
        return kpiData.yearly;
      default:
        return kpiData.monthly;
    }
  };

  // Get the appropriate trend data based on time range
  const getTrendData = () => {
    switch (timeRange) {
      case 'month':
        return trendData.monthly;
      case 'quarter':
        return trendData.quarterly;
      case 'year':
        return trendData.yearly;
      default:
        return trendData.monthly;
    }
  };

  useEffect(() => {
    // Simulate data loading
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 800);
    return () => clearTimeout(timer);
  }, [timeRange, activeSectors]);

  const toggleSector = (sectorId: string) => {
    setActiveSectors(prev => {
      if (prev.includes(sectorId)) {
        return prev.filter(id => id !== sectorId);
      } else {
        return [...prev, sectorId];
      }
    });
  };

  return (
    <DataContext.Provider
      value={{
        financialData: getFinancialData(),
        sectorsData,
        kpiData: getKPIData(),
        trendData: getTrendData(),
        timeRange,
        setTimeRange,
        activeSectors,
        toggleSector,
        isLoading
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useFinancialData = (): FinancialContextType => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useFinancialData must be used within a DataProvider');
  }
  return context;
};