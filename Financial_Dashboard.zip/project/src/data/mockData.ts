// Monthly financial performance data
export const monthlyData = [
  { month: 'Jan', revenue: 120000, expenses: 65000, profit: 55000, performance: 92, efficiency: 85, satisfaction: 88 },
  { month: 'Feb', revenue: 132000, expenses: 70000, profit: 62000, performance: 94, efficiency: 87, satisfaction: 89 },
  { month: 'Mar', revenue: 141000, expenses: 68000, profit: 73000, performance: 95, efficiency: 88, satisfaction: 90 },
  { month: 'Apr', revenue: 160000, expenses: 79000, profit: 81000, performance: 93, efficiency: 86, satisfaction: 91 },
  { month: 'May', revenue: 175000, expenses: 82000, profit: 93000, performance: 96, efficiency: 89, satisfaction: 92 },
  { month: 'Jun', revenue: 190000, expenses: 85000, profit: 105000, performance: 97, efficiency: 90, satisfaction: 93 },
  { month: 'Jul', revenue: 189000, expenses: 87000, profit: 102000, performance: 95, efficiency: 88, satisfaction: 90 },
  { month: 'Aug', revenue: 196000, expenses: 88000, profit: 108000, performance: 96, efficiency: 89, satisfaction: 91 },
  { month: 'Sep', revenue: 205000, expenses: 92000, profit: 113000, performance: 97, efficiency: 91, satisfaction: 92 },
  { month: 'Oct', revenue: 215000, expenses: 97000, profit: 118000, performance: 98, efficiency: 92, satisfaction: 93 },
  { month: 'Nov', revenue: 230000, expenses: 105000, profit: 125000, performance: 98, efficiency: 93, satisfaction: 94 },
  { month: 'Dec', revenue: 245000, expenses: 115000, profit: 130000, performance: 99, efficiency: 94, satisfaction: 95 }
];

// Quarterly financial performance data
export const quarterlyData = [
  { quarter: 'Q1', revenue: 393000, expenses: 203000, profit: 190000, performance: 94, efficiency: 87, satisfaction: 89 },
  { quarter: 'Q2', revenue: 525000, expenses: 246000, profit: 279000, performance: 95, efficiency: 88, satisfaction: 92 },
  { quarter: 'Q3', revenue: 590000, expenses: 267000, profit: 323000, performance: 96, efficiency: 89, satisfaction: 91 },
  { quarter: 'Q4', revenue: 690000, expenses: 317000, profit: 373000, performance: 98, efficiency: 93, satisfaction: 94 }
];

// Yearly financial performance data
export const yearlyData = [
  { year: '2020', revenue: 1850000, expenses: 890000, profit: 960000, performance: 91, efficiency: 84, satisfaction: 87 },
  { year: '2021', revenue: 2100000, expenses: 980000, profit: 1120000, performance: 93, efficiency: 86, satisfaction: 89 },
  { year: '2022', revenue: 2450000, expenses: 1150000, profit: 1300000, performance: 95, efficiency: 88, satisfaction: 91 },
  { year: '2023', revenue: 2998000, expenses: 1435000, profit: 1563000, performance: 97, efficiency: 91, satisfaction: 93 }
];

// Performance metrics by sector
export const performanceMetrics = {
  monthly: {
    tech: { performance: 98, efficiency: 92, satisfaction: 94 },
    finance: { performance: 96, efficiency: 90, satisfaction: 92 },
    health: { performance: 94, efficiency: 88, satisfaction: 90 },
    retail: { performance: 92, efficiency: 86, satisfaction: 88 }
  },
  quarterly: {
    tech: { performance: 97, efficiency: 91, satisfaction: 93 },
    finance: { performance: 95, efficiency: 89, satisfaction: 91 },
    health: { performance: 93, efficiency: 87, satisfaction: 89 },
    retail: { performance: 91, efficiency: 85, satisfaction: 87 }
  },
  yearly: {
    tech: { performance: 96, efficiency: 90, satisfaction: 92 },
    finance: { performance: 94, efficiency: 88, satisfaction: 90 },
    health: { performance: 92, efficiency: 86, satisfaction: 88 },
    retail: { performance: 90, efficiency: 84, satisfaction: 86 }
  }
};

// Sector-based performance
export const sectorsData = [
  { 
    id: 'tech', 
    name: 'Technology', 
    color: '#0F52BA',
    revenue: 980000, 
    growth: 12.5, 
    margin: 28.3,
    performance: 98,
    efficiency: 92,
    satisfaction: 94,
    monthlyData: [48000, 52000, 55000, 62000, 68000, 72000, 71000, 74000, 78000, 82000, 88000, 92000],
    quarterlyData: [155000, 202000, 223000, 262000],
    yearlyData: [780000, 850000, 920000, 980000],
    performanceHistory: [94, 95, 96, 97, 98],
    efficiencyHistory: [88, 89, 90, 91, 92],
    satisfactionHistory: [90, 91, 92, 93, 94]
  },
  { 
    id: 'finance', 
    name: 'Finance', 
    color: '#00A86B',
    revenue: 850000, 
    growth: 8.2, 
    margin: 32.1,
    performance: 96,
    efficiency: 90,
    satisfaction: 92,
    monthlyData: [40000, 45000, 47000, 50000, 55000, 60000, 58000, 62000, 65000, 70000, 75000, 80000],
    quarterlyData: [132000, 165000, 185000, 225000],
    yearlyData: [650000, 720000, 790000, 850000],
    performanceHistory: [92, 93, 94, 95, 96],
    efficiencyHistory: [86, 87, 88, 89, 90],
    satisfactionHistory: [88, 89, 90, 91, 92]
  },
  { 
    id: 'health', 
    name: 'Healthcare', 
    color: '#FFA500',
    revenue: 720000, 
    growth: 15.7, 
    margin: 25.8,
    performance: 94,
    efficiency: 88,
    satisfaction: 90,
    monthlyData: [32000, 35000, 39000, 48000, 52000, 58000, 60000, 60000, 62000, 63000, 67000, 73000],
    quarterlyData: [106000, 158000, 182000, 203000],
    yearlyData: [520000, 590000, 650000, 720000],
    performanceHistory: [90, 91, 92, 93, 94],
    efficiencyHistory: [84, 85, 86, 87, 88],
    satisfactionHistory: [86, 87, 88, 89, 90]
  },
  { 
    id: 'retail', 
    name: 'Retail', 
    color: '#9370DB',
    revenue: 450000, 
    growth: 5.3, 
    margin: 18.5,
    performance: 92,
    efficiency: 86,
    satisfaction: 88,
    monthlyData: [28000, 30000, 32000, 35000, 38000, 42000, 40000, 45000, 50000, 55000, 62000, 68000],
    quarterlyData: [90000, 115000, 135000, 185000],
    yearlyData: [380000, 400000, 420000, 450000],
    performanceHistory: [88, 89, 90, 91, 92],
    efficiencyHistory: [82, 83, 84, 85, 86],
    satisfactionHistory: [84, 85, 86, 87, 88]
  }
];

// KPI data with different time ranges
export const kpiData = {
  monthly: [
    { 
      title: 'Total Revenue', 
      value: '$245K', 
      change: 6.5, 
      trend: 'up',
      chart: [215, 220, 225, 230, 235, 240, 245],
      performance: 99
    },
    { 
      title: 'Gross Profit', 
      value: '$130K', 
      change: 4.0, 
      trend: 'up',
      chart: [118, 120, 122, 125, 127, 128, 130],
      performance: 97
    },
    { 
      title: 'Operating Margin', 
      value: '26.3%', 
      change: 0.8, 
      trend: 'up',
      chart: [25.5, 25.7, 25.8, 26.0, 26.1, 26.2, 26.3],
      performance: 95
    },
    { 
      title: 'Cost Ratio', 
      value: '45.2%', 
      change: -0.5, 
      trend: 'down',
      chart: [45.7, 45.6, 45.5, 45.4, 45.3, 45.2, 45.2],
      performance: 94
    }
  ],
  quarterly: [
    { 
      title: 'Total Revenue', 
      value: '$690K', 
      change: 16.9, 
      trend: 'up',
      chart: [525, 560, 590, 620, 650, 670, 690],
      performance: 98
    },
    { 
      title: 'Gross Profit', 
      value: '$373K', 
      change: 15.5, 
      trend: 'up',
      chart: [279, 295, 310, 330, 345, 360, 373],
      performance: 96
    },
    { 
      title: 'Operating Margin', 
      value: '28.5%', 
      change: 2.1, 
      trend: 'up',
      chart: [26.4, 26.8, 27.2, 27.6, 28.0, 28.3, 28.5],
      performance: 94
    },
    { 
      title: 'Cost Ratio', 
      value: '43.8%', 
      change: -1.8, 
      trend: 'down',
      chart: [45.6, 45.2, 44.8, 44.4, 44.2, 44.0, 43.8],
      performance: 93
    }
  ],
  yearly: [
    { 
      title: 'Total Revenue', 
      value: '$2.998M', 
      change: 22.4, 
      trend: 'up',
      chart: [2100, 2250, 2450, 2600, 2750, 2900, 2998],
      performance: 97
    },
    { 
      title: 'Gross Profit', 
      value: '$1.563M', 
      change: 20.2, 
      trend: 'up',
      chart: [1120, 1220, 1300, 1380, 1450, 1520, 1563],
      performance: 95
    },
    { 
      title: 'Operating Margin', 
      value: '29.8%', 
      change: 3.5, 
      trend: 'up',
      chart: [26.3, 27.0, 27.8, 28.4, 29.0, 29.5, 29.8],
      performance: 93
    },
    { 
      title: 'Cost Ratio', 
      value: '42.5%', 
      change: -2.8, 
      trend: 'down',
      chart: [45.3, 44.8, 44.2, 43.6, 43.2, 42.8, 42.5],
      performance: 92
    }
  ]
};

// Trend prediction data for different time ranges
export const trendData = {
  monthly: {
    revenue: {
      actual: [215, 230, 245],
      predicted: [215, 230, 245, 260, 275, 290]
    },
    expenses: {
      actual: [97, 105, 115],
      predicted: [97, 105, 115, 122, 130, 137]
    },
    profit: {
      actual: [118, 125, 130],
      predicted: [118, 125, 130, 138, 145, 153]
    },
    performance: {
      actual: [96, 97, 98],
      predicted: [96, 97, 98, 98, 99, 99]
    }
  },
  quarterly: {
    revenue: {
      actual: [525, 590, 690],
      predicted: [525, 590, 690, 750, 810, 870]
    },
    expenses: {
      actual: [246, 267, 317],
      predicted: [246, 267, 317, 340, 365, 390]
    },
    profit: {
      actual: [279, 323, 373],
      predicted: [279, 323, 373, 410, 445, 480]
    },
    performance: {
      actual: [94, 95, 96],
      predicted: [94, 95, 96, 97, 97, 98]
    }
  },
  yearly: {
    revenue: {
      actual: [2100, 2450, 2998],
      predicted: [2100, 2450, 2998, 3300, 3650, 4000]
    },
    expenses: {
      actual: [980, 1150, 1435],
      predicted: [980, 1150, 1435, 1580, 1750, 1920]
    },
    profit: {
      actual: [1120, 1300, 1563],
      predicted: [1120, 1300, 1563, 1720, 1900, 2080]
    },
    performance: {
      actual: [92, 94, 96],
      predicted: [92, 94, 96, 97, 98, 98]
    }
  }
};