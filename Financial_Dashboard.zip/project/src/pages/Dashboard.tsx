import React from 'react';
import { useFinancialData } from '../context/DataContext';
import KPICard from '../components/KPICard';
import RevenueChart from '../components/charts/RevenueChart';
import SectorPerformance from '../components/charts/SectorPerformance';
import ExpenseBreakdown from '../components/charts/ExpenseBreakdown';
import TrendPrediction from '../components/charts/TrendPrediction';
import TimeFilter from '../components/filters/TimeFilter';

const Dashboard: React.FC = () => {
  const { kpiData, isLoading } = useFinancialData();

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Financial Dashboard</h1>
        <TimeFilter />
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiData.map((kpi, index) => (
          <KPICard key={index} data={kpi} isLoading={isLoading} />
        ))}
      </div>

      {/* Main Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 transition-all duration-200">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Revenue vs Expenses</h2>
          <RevenueChart isLoading={isLoading} />
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 transition-all duration-200">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Sector Performance</h2>
          <SectorPerformance isLoading={isLoading} />
        </div>
      </div>

      {/* Secondary Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 transition-all duration-200">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Expense Breakdown</h2>
          <ExpenseBreakdown isLoading={isLoading} />
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 transition-all duration-200">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Trend Prediction</h2>
          <TrendPrediction isLoading={isLoading} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;